# generated from catkin/cmake/template/order_packages.context.py.in
source_root_dir = "/home/chrisliu/桌面/Notes/Vrep/V-Rep_Steeringwheel_tutorial/vrep_ws/src"
whitelisted_packages = "".split(';') if "" != "" else []
blacklisted_packages = "".split(';') if "" != "" else []
underlay_workspaces = "/home/chrisliu/ROS/motion_planning_ws/devel;/home/chrisliu/ROS/learn_opencv/devel;/home/chrisliu/ROS/vrep_ws/devel;/opt/ros/kinetic".split(';') if "/home/chrisliu/ROS/motion_planning_ws/devel;/home/chrisliu/ROS/learn_opencv/devel;/home/chrisliu/ROS/vrep_ws/devel;/opt/ros/kinetic" != "" else []
